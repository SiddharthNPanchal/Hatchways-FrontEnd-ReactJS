import Students from "./components/students";

function App() {
  return (
    <div>
      <Students/>
    </div>
  );
}

export default App;
