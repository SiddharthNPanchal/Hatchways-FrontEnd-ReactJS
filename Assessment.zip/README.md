Author: Siddharth Panchal
Email: sidnkpanchal@gmail.com

Instructions to run the project:

1. run command: npm install
2. run command: npm start
